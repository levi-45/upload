#!/usr/bin/python
# -*- coding: utf-8 -*-

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
from os.path import dirname, join
import os
import sys

__version__ = "3.4"
NAME_PLUG = "Softcam Manager"
TITLE_PLUG = "..:: " + NAME_PLUG + " V. %s ::.." % __version__
PLUGIN_PATH = dirname(sys.modules[__name__].__file__)
ICONPIC = join(PLUGIN_PATH, "logo.png")
DATA_PATH = join(PLUGIN_PATH, "data")
DIR_WORK = "/usr/lib/enigma2/python/Screens"
FILE_XML = join(PLUGIN_PATH, "tvManager.xml")
ECM_INFO = "/tmp/ecm.info"
EMPTY_ECM_INFO = ("", "0", "0", "0")

sl = 'slManager'
PluginLanguageDomain = 'tvManager'
PluginLanguagePath = 'Extensions/tvManager/locale'


headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Encoding": "deflate"}


global isDreamOS
isDreamOS = False
if os.path.exists("/var/lib/dpkg/status"):
    isDreamOS = True


# def wgetsts():
    # wgetsts = False
    # cmd22 = 'find /usr/bin -name "wget"'
    # res = os.popen(cmd22).read()
    # if 'wget' not in res.lower():
    # if os.path.exists("/var/lib/dpkg/status"):
    # cmd23 = 'apt-get update && apt-get install wget'
    # os.popen(cmd23)
    # wgetsts = True
    # else:
    # cmd23 = 'opkg update && opkg install wget'
    # os.popen(cmd23)
    # wgetsts = True
    # return wgetsts


def wgetsts():
    if os.path.exists("/usr/bin/wget"):
        return False

    # Installa in background
    import threading

    def _install():
        os.system("opkg update && opkg install wget > /dev/null 2>&1 &")
    threading.Thread(target=_install, daemon=True).start()
    return True


def paypal():
    conthelp = "If you like what I do you\n"
    conthelp += "can contribute with a coffee\n"
    conthelp += "scan the qr code and donate € 1.00"
    return conthelp


def localeInit():
    if isDreamOS:  # check if opendreambox image
        # getLanguage returns e.g. "fi_FI" for "language_country"
        lang = language.getLanguage()[:2]
        # Enigma doesn't set this (or LC_ALL, LC_MESSAGES, LANG). gettext needs
        # it!
        os.environ["LANGUAGE"] = lang
    gettext.bindtextdomain(
        PluginLanguageDomain,
        resolveFilename(
            SCOPE_PLUGINS,
            PluginLanguagePath))


if isDreamOS:  # check if DreamOS image
    def _(txt):
        return gettext.dgettext(PluginLanguageDomain, txt) if txt else ""
else:
    def _(txt):
        translation = gettext.dgettext(PluginLanguageDomain, txt)
        if translation:
            return translation
        else:
            print(("[%s] fallback to default translation for %s" %
                  (PluginLanguageDomain, txt)))
            return gettext.gettext(txt)


localeInit()
language.addCallback(localeInit)
ftpxml = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2xldmktNDUvTXVsdGljYW0vbWFpbi9DYW1pbnN0YWxsZXIueG1s'
installer_url = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0JlbGZhZ29yMjAwNS90dk1hbmFnZXIvbWFpbi9pbnN0YWxsZXIuc2g='
developer_url = 'aHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9yZXBvcy9CZWxmYWdvcjIwMDUvdHZNYW5hZ2Vy'
