#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
****************************************
*        coded by Lululla & PCD        *
*             skin by MMark            *
*             26/03/2023               *
*       Skin by MMark                  *
****************************************
# --------------------#
# Info http://t.me/tivustream
'''
from __future__ import print_function
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.Screen import Screen
from Tools.Directories import (SCOPE_PLUGINS, resolveFilename)
from enigma import eTimer
import codecs
import os
import re
import six
import ssl
import sys
import unicodedata
from Plugins.Extensions.xxxplugin import (_, skin_path)
from Plugins.Extensions.xxxplugin.lib import (Utils, html_conv)
from Plugins.Extensions.xxxplugin.plugin import (
    rvList,
    Playstream1,
    # Playstream2,
    # showlist,
    rvoneListEntry,
    show_,
)
PY3 = sys.version_info.major >= 3
print('Py3: ', PY3)


if sys.version_info >= (2, 7, 9):
    try:
        sslContext = ssl._create_unverified_context()
    except BaseException:
        sslContext = None

currversion = '1.0'
title_plug = 'Milf300 '
desc_plugin = ('..:: Milf300 by Lululla %s ::.. ' % currversion)
PLUGIN_PATH = resolveFilename(
    SCOPE_PLUGINS,
    "Extensions/{}".format('xxxplugin'))
current = os.path.dirname(os.path.realpath(__file__))
parent = os.path.dirname(current)
sys.path.append(parent)
print(current)
print(parent)
pluglogo = os.path.join(PLUGIN_PATH, 'pic/milf300.png')
stripurl = 'aHR0cHM6Ly93d3cubWlsZjMwMC5jb20'
_session = None
Path_Movies = '/tmp/'
# global search
search = False
video = False

if PY3:
    PY3 = True
    unicode = str
else:
    str = str


def normalize(title):
    try:
        try:
            return title.decode('ascii').encode("utf-8")
        except BaseException:
            pass

        return str(
            ''.join(
                c for c in unicodedata.normalize(
                    'NFKD',
                    unicode(
                        title.decode('utf-8'))) if unicodedata.category(c) != 'Mn'))
    except BaseException:
        return html_conv.html_unescape(title)


Panel_list = [
    ('Milf300 Pornstars'),
    ('Milf300 More Videos'),
    ('SEARCH'),
]


class main(Screen):
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        skin = os.path.join(skin_path, 'defaultListScreen.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = f.read()
        self.menulist = []
        self['menulist'] = rvList([])
        self['red'] = Label(_('Back'))
        # self['green'] = Label(_('Export'))
        self['title'] = Label('')
        self['title'].setText(title_plug)
        self['name'] = Label('')
        self['text'] = Label('Only for Adult by Lululla')
        self['poster'] = Pixmap()
        self.currentList = 'menulist'
        self.loading_ok = False
        self.count = 0
        self.loading = 0
        self['actions'] = ActionMap(
            ['OkCancelActions',
             'ColorActions',
             'DirectionActions',
             'MovieSelectionActions'],
            {
                'up': self.up,
                'down': self.down,
                'left': self.left,
                'right': self.right,
                'ok': self.ok,
                'green': self.ok,
                'cancel': self.exit,
                'red': self.exit
            },
            -1
        )
        self.onLayoutFinish.append(self.updateMenuList)

    def updateMenuList(self):
        self.menu_list = []
        for x in self.menu_list:
            del self.menu_list[0]
        list = []
        idx = 0
        for x in Panel_list:
            list.append(rvoneListEntry(x))
            self.menu_list.append(x)
            idx += 1
        self['menulist'].setList(list)
        auswahl = self['menulist'].getCurrent()[0]
        self['name'].setText(str(auswahl))

    def search_text(self, name, url):
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        self.namex = name
        self.urlx = url
        self.session.openWithCallback(
            self.filterChannels,
            VirtualKeyBoard,
            title=_("Filter this category..."),
            text=''
        )

    def filterChannels(self, result):
        if result:
            global search
            name = str(result)
            url = self.urlx + str(result) + '/'
            try:
                search = True
                self.session.open(milf3002, name, url)
            except BaseException:
                return
        else:
            self.resetSearch()

    def resetSearch(self):
        global search
        search = False

    def ok(self):
        self.keyNumberGlobalCB(self['menulist'].getSelectedIndex())

    def keyNumberGlobalCB(self, idx):
        global namex, lnk
        namex = ''
        sel = self.menu_list[idx]
        if sel == 'SEARCH':
            namex = sel.upper()
            lnk = 'https://milf300.b-cdn.net/search?query='
            self.search_text(namex, lnk)
        if sel == ("Milf300 Pornstars"):
            namex = "pornstars"
            lnk = 'https://milf300.b-cdn.net/pornstars/'
            self.session.open(milf3002, namex, lnk)
        elif sel == ("Milf300 More Videos"):
            namex = "videos"
            lnk = 'https://milf300.b-cdn.net/videos/'
            self.session.open(milf3002, namex, lnk)
        else:
            return

    def up(self):
        self[self.currentList].up()
        auswahl = self['menulist'].getCurrent()[0]
        self['name'].setText(str(auswahl))

    def down(self):
        self[self.currentList].down()
        auswahl = self['menulist'].getCurrent()[0]
        self['name'].setText(str(auswahl))

    def left(self):
        self[self.currentList].pageUp()
        auswahl = self['menulist'].getCurrent()[0]
        self['name'].setText(str(auswahl))

    def right(self):
        self[self.currentList].pageDown()
        auswahl = self['menulist'].getCurrent()[0]
        self['name'].setText(str(auswahl))

    def exit(self):
        global search
        if search is True:
            search = False
            self.updateMenuList()
        else:
            self.close()


class milf3002(Screen):
    def __init__(self, session, name, url):
        self.session = session
        Screen.__init__(self, session)
        skin = os.path.join(skin_path, 'defaultListScreen.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = f.read()
        self.menulist = []
        self.loading_ok = False
        self.count = 0
        self.loading = 0
        self.name = name
        self.url = url
        self['menulist'] = rvList([])
        self['red'] = Label(_('Back'))
        self['title'] = Label('')
        self['title'].setText(title_plug)
        self['name'] = Label('')
        self['poster'] = Pixmap()
        self['text'] = Label('Only for Adult by Lululla')
        self.currentList = 'menulist'
        self['actions'] = ActionMap(
            ['OkCancelActions',
             'ColorActions',
             'DirectionActions',
             'MovieSelectionActions'],
            {
                'cancel': self.exit,
                'ok': self.ok,
                'red': self.exit
            },
            -1
        )
        self.timer = eTimer()
        if Utils.DreamOS():
            self.timer_conn = self.timer.timeout.connect(self._gotPageLoad)
        else:
            self.timer.callback.append(self._gotPageLoad)
        self.timer.start(500, True)

    def _gotPageLoad(self):
        self.cat_list = []
        name = self.name
        try:
            pages = 100
            i = 1
            while i < pages:
                page = str(i)
                url1 = self.url + "?page=" + page
                name = "Page " + page
                i += 1
                self.cat_list.append(show_(name, url1))
            if len(self.cat_list) < 0:
                return
            else:
                self['menulist'].l.setList(self.cat_list)
                self['menulist'].moveToIndex(0)
                auswahl = self['menulist'].getCurrent()[0][0]
                self['name'].setText(str(auswahl))
        except Exception as e:
            print(e)
            self['name'].setText(_('Nothing ... Retry'))

    def ok(self):
        name = self['menulist'].getCurrent()[0][0]
        url = self['menulist'].getCurrent()[0][1]
        print('pages url: ', url)
        self.session.open(milf3003, name, url)

    def exit(self):
        global search
        search = False
        self.close()


class milf3003(Screen):
    def __init__(self, session, name, url):
        self.session = session
        Screen.__init__(self, session)
        skin = os.path.join(skin_path, 'defaultListScreen.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = f.read()
        self.menulist = []
        self['menulist'] = rvList([])
        self['red'] = Label(_('Back'))
        # self['green'] = Label(_('Export'))
        self['title'] = Label('')
        self['title'].setText(title_plug)
        self['name'] = Label('')
        self['text'] = Label('Only for Adult by Lululla')
        self['poster'] = Pixmap()
        self.name = name
        self.url = url
        self.currentList = 'menulist'
        self.loading_ok = False
        self.count = 0
        self.loading = 0
        self['actions'] = ActionMap(
            ['OkCancelActions',
             'ColorActions',
             'DirectionActions',
             'MovieSelectionActions'],
            {
                'up': self.up,
                'down': self.down,
                'left': self.left,
                'right': self.right,
                'ok': self.ok,
                'green': self.ok,
                'cancel': self.exit,
                'red': self.exit
            },
            -1
        )
        self.timer = eTimer()
        if Utils.DreamOS():
            self.timer_conn = self.timer.timeout.connect(self.cat)
        else:
            self.timer.callback.append(self.cat)
        self.timer.start(500, True)

    def up(self):
        self[self.currentList].up()
        auswahl = self['menulist'].getCurrent()[0][0]
        self['name'].setText(str(auswahl))

    def down(self):
        self[self.currentList].down()
        auswahl = self['menulist'].getCurrent()[0][0]
        self['name'].setText(str(auswahl))

    def left(self):
        self[self.currentList].pageUp()
        auswahl = self['menulist'].getCurrent()[0][0]
        self['name'].setText(str(auswahl))

    def right(self):
        self[self.currentList].pageDown()
        auswahl = self['menulist'].getCurrent()[0][0]
        self['name'].setText(str(auswahl))

    def cat(self):
        self.cat_list = []
        try:
            content = Utils.getUrl2(self.url, 'https://milf300.b-cdn.net/')
            if six.PY3:
                content = six.ensure_str(content)
            global video
            if 'source src=' in content:
                video = True
            regexcat = 'a class="ads-link" href="(.*?)".*?card-text">(.*?)<'
            match = re.compile(regexcat, re.DOTALL).findall(content)
            for url, name in match:
                name = name
                url = "https://milf300.b-cdn.net" + url
                self.cat_list.append(show_(name, url))

            if len(self.cat_list) < 0:
                return
            else:
                self['menulist'].l.setList(self.cat_list)
                self['menulist'].moveToIndex(0)
                auswahl = self['menulist'].getCurrent()[0][0]
                self['name'].setText(str(auswahl))
        except Exception as e:
            print(e)

    def ok(self):
        try:
            name = self['menulist'].getCurrent()[0][0]
            url = self['menulist'].getCurrent()[0][1]
            # print("url1 B =", url)
            self.play_that_shit(url, name)
        except Exception as e:
            print(e)

    def play_that_shit(self, url, name):
        print('Video= ', video)
        if video is True:
            self.session.open(milf3004, str(name), str(url))
        else:
            self.session.open(milf3002, str(name), str(url))

    def exit(self):
        global search, video
        search = False
        video = False
        self.close()


class milf3004(Screen):
    def __init__(self, session, name, url):
        self.session = session
        Screen.__init__(self, session)
        skin = os.path.join(skin_path, 'defaultListScreen.xml')
        with codecs.open(skin, "r", encoding="utf-8") as f:
            self.skin = f.read()
        self.menulist = []
        self['menulist'] = rvList([])
        self['red'] = Label(_('Back'))
        # self['green'] = Label(_('Export'))
        self['title'] = Label('')
        self['title'].setText(title_plug)
        self['name'] = Label('')
        self['text'] = Label('Only for Adult by Lululla')
        self['poster'] = Pixmap()
        self.name = name
        self.url = url
        self.currentList = 'menulist'
        self.loading_ok = False
        self.count = 0
        self.loading = 0
        self['actions'] = ActionMap(
            ['OkCancelActions',
             'ColorActions',
             'DirectionActions',
             'MovieSelectionActions'],
            {
                'up': self.up,
                'down': self.down,
                'left': self.left,
                'right': self.right,
                'ok': self.ok,
                'green': self.ok,
                'cancel': self.exit,
                'red': self.exit
            },
            -1
        )
        self.timer = eTimer()
        if Utils.DreamOS():
            self.timer_conn = self.timer.timeout.connect(self.cat)
        else:
            self.timer.callback.append(self.cat)
        self.timer.start(500, True)

    def up(self):
        self[self.currentList].up()
        auswahl = self['menulist'].getCurrent()[0][0]
        self['name'].setText(str(auswahl))

    def down(self):
        self[self.currentList].down()
        auswahl = self['menulist'].getCurrent()[0][0]
        self['name'].setText(str(auswahl))

    def left(self):
        self[self.currentList].pageUp()
        auswahl = self['menulist'].getCurrent()[0][0]
        self['name'].setText(str(auswahl))

    def right(self):
        self[self.currentList].pageDown()
        auswahl = self['menulist'].getCurrent()[0][0]
        self['name'].setText(str(auswahl))

    def cat(self):
        self.cat_list = []
        try:
            content = Utils.getUrl2(self.url, 'https://milf300.b-cdn.net/')
            if six.PY3:
                content = six.ensure_str(content)
            regexcat = 'source src="(.*?)"'
            match = re.compile(regexcat, re.DOTALL).findall(content)
            url = match[0]
            url = url.replace("&amp;", "&")
            name = self.name
            self.cat_list.append(show_(name, url))
            if len(self.cat_list) < 0:
                return
            else:
                self['menulist'].l.setList(self.cat_list)
                self['menulist'].moveToIndex(0)
                auswahl = self['menulist'].getCurrent()[0][0]
                self['name'].setText(str(auswahl))
        except Exception as e:
            print(e)

    def ok(self):
        try:
            name = self['menulist'].getCurrent()[0][0]
            url = self['menulist'].getCurrent()[0][1]
            self.play_that_shit(url, name)
        except Exception as e:
            print(e)

    def play_that_shit(self, url, name):
        self.session.open(Playstream1, str(name), str(url))

    def exit(self):
        self.close()
