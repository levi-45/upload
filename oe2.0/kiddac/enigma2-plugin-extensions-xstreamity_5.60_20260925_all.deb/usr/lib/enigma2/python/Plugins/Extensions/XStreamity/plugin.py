#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import shutil
import sys
import time
import glob as glob_module
import twisted.python.runtime

from . import _
from Components.config import (
    config, ConfigSubsection, ConfigSelection, ConfigDirectory,
    ConfigYesNo, ConfigSelectionNumber, ConfigClock, ConfigPIN,
    ConfigInteger, configfile, ConfigText
)
from enigma import eTimer, getDesktop, addFont
from Plugins.Plugin import PluginDescriptor
from os.path import isdir

# ------------------------------------------------------------------
# Basic environment / platform checks
# ------------------------------------------------------------------

pythonFull = float(str(sys.version_info.major) + "." + str(sys.version_info.minor))
pythonVer = sys.version_info.major
isDreambox = os.path.exists("/usr/bin/apt-get")
debugs = False

# ------------------------------------------------------------------
# Dependencies checks
# ------------------------------------------------------------------

try:
    from multiprocessing.pool import ThreadPool
    hasMultiprocessing = True
except ImportError:
    hasMultiprocessing = False

try:
    from concurrent.futures import ThreadPoolExecutor
    if twisted.python.runtime.platform.supportsThreads():
        hasConcurrent = True
    else:
        hasConcurrent = False
except ImportError:
    hasConcurrent = False


# ------------------------------------------------------------------
# Paths
# ------------------------------------------------------------------

dir_etc = "/etc/enigma2/xstreamity/"
dir_tmp = "/etc/enigma2/xstreamity/tmp/"
dir_plugins = "/usr/lib/enigma2/python/Plugins/Extensions/XStreamity/"
dir_videos = os.path.join(dir_plugins, "video/")

# ------------------------------------------------------------------
# Version
# ------------------------------------------------------------------

version = ""
try:
    with open(os.path.join(dir_plugins, "version.txt"), "r") as f:
        version = f.readline().strip()
except:
    version = ""


# ------------------------------------------------------------------
# Video list (for XKlass)
# ------------------------------------------------------------------

try:
    files = os.listdir(dir_videos)
    video_extensions = ('.mp4', '.avi', '.mkv')
    video_files = [file for file in files if file.endswith(video_extensions)]
    video_list = [(os.path.join(dir_videos, file), file) for file in video_files]
except:
    video_list = []

# ------------------------------------------------------------------
# Language & User-Agent options
# ------------------------------------------------------------------

languages = [
    ("", "English"),
    ("de-DE", "Deutsch"),
    ("es-ES", "Español"),
    ("fr-FR", "Français"),
    ("it-IT", "Italiano"),
    ("nl-NL", "Nederlands"),
    ("tr-TR", "Türkçe"),
    ("cs-CZ", "Český"),
    ("da-DK", "Dansk"),
    ("hr-HR", "Hrvatski"),
    ("hu-HU", "Magyar"),
    ("no-NO", "Norsk"),
    ("pl-PL", "Polski"),
    ("pt-PT", "Português"),
    ("ro-RO", "Română"),
    ("ru-RU", "Pусский"),
    ("sh-SH", "Srpski"),
    ("sk-SK", "Slovenčina"),
    ("fi-FI", "suomi"),
    ("sv-SE", "svenska"),
    ("uk-UA", "Український"),
    ("ar-SA", "العربية"),
    ("bg-BG", "български език"),
    ("el-GR", "ελληνικά"),
    ("sq-AL", "shqip"),
    ("zh-CN", "中文")
]

useragents = [
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36", "Chrome 145"),
    ("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0", "Firefox 147"),
    ("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36", "Android")
]

# ------------------------------------------------------------------
# Config setup
# ------------------------------------------------------------------

config.plugins.XStreamity = ConfigSubsection()
cfg = config.plugins.XStreamity

cfg.interface = ConfigSelection(
    default="xstreamity",
    choices=[
        ("xstreamity", "XStreamity"),
        ("xklass", "XKlass")
    ]
)

# ------------------------------------------------------------------
# Screen / skin selection
# ------------------------------------------------------------------

def _remove_legacy_black_folder(xstreamity_skin_dir):
    """
    Remove a legacy "Black" skin folder left over from an old rename, using
    an exact-case check via os.listdir() rather than os.path.exists().
    os.path.exists() resolves case-insensitively on some filesystems (e.g.
    Windows/NTFS), so it can't reliably distinguish "Black" from the live
    "black" skin folder. listdir() + a byte-for-byte name comparison can.
    """
    try:
        entries = os.listdir(xstreamity_skin_dir)
    except OSError:
        return
    if "Black" in entries:
        shutil.rmtree(os.path.join(xstreamity_skin_dir, "Black"))


_remove_legacy_black_folder("/usr/lib/enigma2/python/Plugins/Extensions/XStreamity/skins/hd/xstreamity")
_remove_legacy_black_folder("/usr/lib/enigma2/python/Plugins/Extensions/XStreamity/skins/fhd/xstreamity")
_remove_legacy_black_folder("/usr/lib/enigma2/python/Plugins/Extensions/XStreamity/skins/uhd/xstreamity")

screenwidth = getDesktop(0).size()

if screenwidth.width() == 2560:
    skin_directory = os.path.join(dir_plugins, "skins/uhd/")
elif screenwidth.width() > 1280:
    skin_directory = os.path.join(dir_plugins, "skins/fhd/")
else:
    skin_directory = os.path.join(dir_plugins, "skins/hd/")

xstreamity_dir = os.path.join(skin_directory, "xstreamity")
xklass_dir = os.path.join(skin_directory, "xklass")

try:
    xstreamityfolders = os.listdir(xstreamity_dir)
except:
    xstreamityfolders = ["default"]

try:
    xklassfolders = os.listdir(xklass_dir)
except:
    xklassfolders = ["default"]

live_streamtype_choices = [("1", "DVB(1)"), ("4097", "IPTV(4097)")]
vod_streamtype_choices = [("4097", "IPTV(4097)")]

if os.path.exists("/usr/bin/gstplayer"):
    live_streamtype_choices.append(("5001", "GStreamer(5001)"))
    vod_streamtype_choices.append(("5001", "GStreamer(5001)"))

if os.path.exists("/usr/bin/exteplayer3"):
    live_streamtype_choices.append(("5002", "ExtePlayer(5002)"))
    vod_streamtype_choices.append(("5002", "ExtePlayer(5002)"))

if isDreambox:
    live_streamtype_choices.append(("8193", "DreamOS GStreamer(8193)"))
    vod_streamtype_choices.append(("8193", "DreamOS GStreamer(8193)"))

cfg.livetype = ConfigSelection(default="4097", choices=live_streamtype_choices)
cfg.vodtype = ConfigSelection(default="4097", choices=vod_streamtype_choices)

cfg.ar_id_player = ConfigSelection(default="-1", choices=[
    ("-1", _("Auto")),
    ("0", _("4:3 Letterbox")),
    ("1", _("4:3 PanScan")),
    ("2", _("16:9")),
    ("3", _("16:9 Always")),
    ("4", _("16:10 Letterbox")),
    ("5", _("16:10 PanScan")),
    ("6", _("16:9 Letterbox")),
])

# ------------------------------------------------------------------
# Download location (safe, minimal writes)
# ------------------------------------------------------------------

result = cfg.downloadlocation.value if hasattr(cfg, "downloadlocation") else ""

if not result:
    try:
        if isdir("/media/hdd/movie/"):
            result = "/media/hdd/movie/"
        elif isdir("/media/usb/movie/"):
            result = "/media/usb/movie/"
        elif config.usage.instantrec_path.value:
            result = config.usage.instantrec_path.value
        elif config.movielist.last_videodir.value:
            result = config.movielist.last_videodir.value
        else:
            result = "/media/"
    except Exception as e:
        print(e)
        result = "/media/"

cfg.downloadlocation = ConfigDirectory(default=result)

# ------------------------------------------------------------------
# EPG location (prefer system epgcachepath if available)
# ------------------------------------------------------------------

epg_base = "/etc/enigma2/"

try:
    if hasattr(config, "misc") and hasattr(config.misc, "epgcachepath"):
        epgcachepath = config.misc.epgcachepath.value
        if epgcachepath:
            epg_base = epgcachepath
except:
    pass

cfg.epglocation = ConfigDirectory(default=epg_base)
cfg.location = ConfigDirectory(default=dir_etc)
cfg.main = ConfigYesNo(default=True)
cfg.livepreview = ConfigYesNo(default=True)
cfg.stopstream = ConfigYesNo(default=False)
cfg.xstreamity_skin = ConfigSelection(default="default", choices=xstreamityfolders)
cfg.xklass_skin = ConfigSelection(default="default", choices=xklassfolders)
cfg.timeout = ConfigSelectionNumber(1, 20, 1, default=20, wraparound=True)
cfg.TMDB = ConfigYesNo(default=True)
cfg.TMDBLanguage2 = ConfigSelection(default="", choices=languages)
cfg.catchupstart = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.catchupend = ConfigSelectionNumber(0, 30, 1, default=0, wraparound=True)
cfg.subs = ConfigYesNo(default=False)
cfg.skipplaylistsscreen = ConfigYesNo(default=False)
cfg.wakeup = ConfigClock(default=((9 * 60) + 9) * 60)
cfg.adult = ConfigYesNo(default=False)
cfg.adultpin = ConfigPIN(default=0000)
cfg.retries = ConfigSubsection()
cfg.retries.adultpin = ConfigSubsection()
cfg.retries.adultpin.tries = ConfigInteger(default=3)
cfg.retries.adultpin.time = ConfigInteger(default=3)
cfg.location_valid = ConfigYesNo(default=True)

cfg.channelpicons = ConfigYesNo(default=True)
cfg.infobarpicons = ConfigYesNo(default=True)
cfg.channelcovers = ConfigYesNo(default=True)
cfg.infobarcovers = ConfigYesNo(default=True)

cfg.introvideo = ConfigYesNo(default=True)
cfg.introloop = ConfigYesNo(default=False)
cfg.introvideoselection = ConfigSelection(choices=video_list)
cfg.speedtest = ConfigYesNo(default=False)

cfg.startmenuplaylists = ConfigYesNo(default=True)
cfg.manageplaylists = ConfigYesNo(default=True)
cfg.sidemenumanageplaylists = ConfigYesNo(default=True)
cfg.sidemenuaccountinfo = ConfigYesNo(default=True)

cfg.boot = ConfigYesNo(default=False)
cfg.useragent = ConfigSelection(default="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36", choices=useragents)
cfg.lastplaylist = ConfigText()

cfg.vodcategoryorder = ConfigSelection(default=(_("Sort: Original")), choices=[(_("Sort: A-Z"), "A-Z"), (_("Sort: Z-A"), "Z-A"), (_("Sort: Original"), _("Original"))])
cfg.vodstreamorder = ConfigSelection(default=(_("Sort: Original")), choices=[(_("Sort: A-Z"), "A-Z"), (_("Sort: Z-A"), "Z-A"), (_("Sort: Added"), _("Added")), (_("Sort: Year"), _("Year")), (_("Sort: Original"), _("Original"))])

cfg.seriescategoryorder = ConfigSelection(default=(_("Sort: Original")), choices=[(_("Sort: A-Z"), "A-Z"), (_("Sort: Z-A"), "Z-A"), (_("Sort: Original"), _("Original"))])
cfg.seriesorder = ConfigSelection(default=(_("Sort: Original")), choices=[(_("Sort: A-Z"), "A-Z"), (_("Sort: Z-A"), "Z-A"), (_("Sort: Added"), _("Added")), (_("Sort: Year"), _("Year")), (_("Sort: Original"), _("Original"))])

# ------------------------------------------------------------------
# File paths
# ------------------------------------------------------------------

downloads_json = os.path.join(dir_etc, "downloads2.json")
common_path = os.path.join(skin_directory, "common/")


def get_playlist_choices(location=None):
    """Return selectable text files from the configured playlist directory."""
    location = location or cfg.location.value or dir_etc
    filenames = []

    try:
        if os.path.isdir(location):
            filenames = [
                filename for filename in os.listdir(location)
                if filename.lower().endswith(".txt") and
                os.path.isfile(os.path.join(location, filename))
            ]
    except Exception:
        filenames = []

    filenames = sorted(set(filenames), key=lambda filename: filename.lower())
    if "playlists.txt" in filenames:
        filenames.remove("playlists.txt")
    filenames.insert(0, "playlists.txt")

    return [(filename, filename) for filename in filenames]


cfg.playlist_name = ConfigSelection(default="playlists.txt", choices=get_playlist_choices())


def refresh_playlist_choices(location=None):
    """Refresh the filename selector while preserving a valid selection."""
    choices = get_playlist_choices(location)
    filenames = [choice[0] for choice in choices]
    selected = os.path.basename(cfg.playlist_name.value or "playlists.txt")

    if selected not in filenames:
        selected = "playlists.txt"

    cfg.playlist_name.setChoices(choices, default="playlists.txt")
    cfg.playlist_name.setValue(selected)
    return choices


def refresh_playlist_paths(create_files=True):
    """Update the active text and JSON paths without requiring a GUI restart."""
    location = cfg.location.value or dir_etc

    try:
        if not os.path.isdir(location):
            os.makedirs(location)
        cfg.location_valid.setValue(True)
    except Exception:
        location = dir_etc
        cfg.location.setValue(location)
        cfg.location_valid.setValue(False)
        if not os.path.isdir(location):
            os.makedirs(location)

    refresh_playlist_choices(location)
    filename = os.path.basename(cfg.playlist_name.value or "playlists.txt")
    if not filename.lower().endswith(".txt"):
        filename = "playlists.txt"
        cfg.playlist_name.setValue(filename)

    playlist_file = os.path.join(location, filename)
    file_stem = os.path.splitext(filename)[0]
    json_filename = "x-playlists.json" if filename == "playlists.txt" else "{}-data.json".format(file_stem)
    playlists_json = os.path.join(dir_etc, json_filename)

    cfg.playlist_file.setValue(playlist_file)
    cfg.playlists_json.setValue(playlists_json)

    if create_files:
        for path in (playlist_file, playlists_json):
            if not os.path.isfile(path):
                with open(path, "a"):
                    pass

    return playlist_file, playlists_json


cfg.playlist_file = ConfigText(default=os.path.join(dir_etc, "playlists.txt"))
cfg.playlists_json = ConfigText(default=os.path.join(dir_etc, "x-playlists.json"))
cfg.downloads_json = ConfigText(downloads_json)
refresh_playlist_paths()

cfg.save()
configfile.save()

if os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/InternetSpeedTest"):
    InternetSpeedTest_installed = True
else:
    InternetSpeedTest_installed = False


if os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/NetSpeedTest"):
    NetSpeedTest_installed = True
else:
    NetSpeedTest_installed = False

# Check folders
# ------------------------------------------------------------------

# create folder for working files
if not os.path.exists(dir_etc):
    os.makedirs(dir_etc)

# create temporary folder for downloaded files
if not os.path.exists(dir_tmp):
    os.makedirs(dir_tmp)

# check if x-downloads.json file exists in specified location
if not os.path.isfile(cfg.downloads_json.value):
    with open(cfg.downloads_json.value, "a") as f:
        f.close()

# ------------------------------------------------------------------
# Fonts (safe)
# ------------------------------------------------------------------

font_folder = os.path.join(dir_plugins, "fonts/")
for font, name in [
    ("m-plus-rounded-1c-regular.ttf", "xstreamityregular"),
    ("m-plus-rounded-1c-medium.ttf", "xstreamitybold"),
    ("slyk-medium.ttf", "slykregular"),
    ("slyk-bold.ttf", "slykbold"),
    ("classfont2.ttf", "klass"),
]:
    try:
        addFont(os.path.join(font_folder, font), name, 100, 0)
    except:
        pass


# ------------------------------------------------------------------
# Headers
# ------------------------------------------------------------------

hdr = {
    'User-Agent': str(cfg.useragent.value)
}


# ------------------------------------------------------------------
# Main entry
# ------------------------------------------------------------------

def main(session, **kwargs):
    if os.path.exists(dir_tmp):
        shutil.rmtree(dir_tmp)
    os.makedirs(dir_tmp)

    epg_root = os.path.join(str(cfg.epglocation.value).rstrip("/"), "iptv-epg")

    if os.path.isdir(epg_root):
        epgfolder = os.path.join(epg_root, '*', '*.xml')
        for file_path in glob_module.glob(epgfolder):
            try:
                os.remove(file_path)
            except:
                pass

    if cfg.interface.value == "xklass":
        from . import startmenu
        session.open(startmenu.XStreamity_StartMenu)
    else:
        from . import mainmenu
        session.open(mainmenu.XStreamity_MainMenu)


# ------------------------------------------------------------------
# Menus / autostart / boot
# ------------------------------------------------------------------

def mainmenu(menu_id, **kwargs):
    if menu_id == "mainmenu":
        return [(_("XStreamity"), main, "XStreamity", 50)]
    return []


class XSAutoStartTimer:
    def __init__(self, session):
        self.session = session
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.onTimer)
        except:
            self.timer.callback.append(self.onTimer)
        self.update()

    def getWakeTime(self):
        clock = cfg.wakeup.value
        nowt = time.time()
        now = time.localtime(nowt)
        return int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday, clock[0], clock[1], 0, now.tm_wday, now.tm_yday, now.tm_isdst)))

    def update(self, atLeast=0):
        self.timer.stop()
        wake = self.getWakeTime()
        now = int(time.time())
        if wake < now + atLeast:
            wake += 86400
        self.timer.startLongTimer(max(60, min(3600, wake - now)))

    def onTimer(self):
        self.timer.stop()
        now = int(time.time())
        wake = self.getWakeTime()
        atLeast = 0
        if abs(wake - now) < 60:
            self.runUpdate()
            atLeast = 60
        self.update(atLeast)

    def runUpdate(self):
        print("\n *********** Updating XStreamity EPG ************ \n")
        from . import update
        update.XStreamity_Update(self.session)


xsAutoStartTimer = None


def autostart(reason, session=None, **kwargs):
    global xsAutoStartTimer
    if reason == 0 and session and xsAutoStartTimer is None:
        xsAutoStartTimer = XSAutoStartTimer(session)


glb_session = None
glb_startDelay = None


class StartDelay:
    def __init__(self):
        self.timerboot = eTimer()

    def start(self):

        try:
            self.timer_conn = self.timerboot.timeout.connect(self.query)
        except:
            self.timerboot.callback.append(self.query)

        self.timerboot.start(2000, True)

    def query(self):
        if cfg.interface.value == "xklass":
            from . import startmenu
            glb_session.open(startmenu.XStreamity_StartMenu)
            return
        else:
            from . import playlists
            glb_session.open(playlists.XStreamity_Playlists)
            return


def bootstart(reason, **kwargs):
    # print("*** bootstart ***")
    global glb_session
    global glb_startDelay
    if reason == 0 and "session" in kwargs:
        glb_session = kwargs["session"]
        glb_startDelay = StartDelay()
        glb_startDelay.start()


# ------------------------------------------------------------------
# PLUGIN DESCRIPTOR
# ------------------------------------------------------------------

def Plugins(**kwargs):
    iconFile = "icons/plugin-icon_sd.png"
    if screenwidth.width() > 1280:
        iconFile = "icons/plugin-icon.png"
    description = _("IPTV Xtream Codes playlists player by KiddaC")
    pluginname = _("XStreamity")

    main_menu = PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_MENU, fnc=mainmenu, needsRestart=True)

    extensions_menu = PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main, needsRestart=True)

    boot_start = PluginDescriptor(name=pluginname, description=description, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=bootstart, needsRestart=True)

    result = [PluginDescriptor(name=pluginname, description=description, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart),
              PluginDescriptor(name=pluginname, description=description, where=PluginDescriptor.WHERE_PLUGINMENU, icon=iconFile, fnc=main)]

    result.append(extensions_menu)

    if cfg.main.value:
        result.append(main_menu)

    if cfg.boot.value:
        result.append(boot_start)

    return result
