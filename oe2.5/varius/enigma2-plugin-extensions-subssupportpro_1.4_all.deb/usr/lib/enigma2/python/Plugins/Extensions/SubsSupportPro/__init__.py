# -*- coding: utf-8 -*-
from __future__ import absolute_import

import gettext
import os

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE

__author__ = "mx3L"
__email__ = "mx3Lmail@gmail.com"
__copyright__ = "Copyright (c) 2014 mx3L"
__license__ = "GPL-v2"
__mod__ = "MNASR"
__mod_email__ = "popking159@gmail.com"


def localeInit():
    lang = language.getLanguage()
    if lang:
        os.environ["LANGUAGE"] = lang[:2]
    gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
    gettext.textdomain("enigma2")
    gettext.bindtextdomain("SubsSupportPro", os.path.join(
        os.path.dirname(__file__), 'locale'))


def _(txt):
    t = gettext.dgettext("SubsSupportPro", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


localeInit()
language.addCallback(localeInit)

# Import at the bottom to avoid circular import issues with the '_' translation function
from .subtitles import SubsProSupport, SubsProSupportStatus, initSubsProSettings  # noqa: E402
